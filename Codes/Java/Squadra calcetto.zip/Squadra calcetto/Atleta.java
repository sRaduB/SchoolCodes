
import java.time.LocalDate;

public class Atleta {
    private String nome;
    private String cognome;
    private LocalDate bDay;
    private double altezza;
    private double peso;

    public Atleta(double altezza, LocalDate bDay, String cognome, String nome, double peso) {
        this.altezza = altezza;
        this.bDay = bDay;
        this.cognome = cognome;
        this.nome = nome;
        this.peso = peso;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCognome() {
        return cognome;
    }

    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    public LocalDate getbDay() {
        return bDay;
    }

    public void setbDay(LocalDate bDay) {
        this.bDay = bDay;
    }

    public double getAltezza() {
        return altezza;
    }

    public void setAltezza(double altezza) {
        this.altezza = altezza;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    

}