
import java.time.LocalDate;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Giocatore g1 = new Giocatore(1, "destro", "Attaccante", 183, LocalDate.of(1986, 02, 20), "Rossi", "Mario", 87.4);
        Giocatore g2 = new Giocatore(2, "destro", "Portiere", 183, LocalDate.of(1986, 02, 20), "Rossi", "Paolo", 87.4);
        Giocatore g3 = new Giocatore(3, "destro", "difensore", 183, LocalDate.of(1986, 02, 20), "Rossi", "Franco", 87.4);
        Giocatore g4 = new Giocatore(4, "destro", "difensore", 183, LocalDate.of(1986, 02, 20), "Rossi", "Luigi", 87.4);
        Giocatore g5 = new Giocatore(5, "destro", "difensore", 183, LocalDate.of(1986, 02, 20), "Rossi", "Alfredo", 87.4);
        Giocatore g6 = new Giocatore(6, "destro", "Attaccante", 183, LocalDate.of(1986, 02, 20), "Rossi", "Antonio", 87.4);
        Giocatore g7 = new Giocatore(7, "destro", "Portiere", 183, LocalDate.of(1986, 02, 20), "Rossi", "Robberto", 87.4);
        Giocatore g8 = new Giocatore(8, "destro", "difensore", 183, LocalDate.of(1986, 02, 20), "Rossi", "Flavio", 87.4);
        Giocatore g9 = new Giocatore(9, "destro", "difensore", 183, LocalDate.of(1986, 02, 20), "Rossi", "Giuseppe", 87.4);
        Giocatore g10 = new Giocatore(10, "destro", "difensore", 183, LocalDate.of(1986, 02, 20), "Rossi", "Giulio", 87.4);

        Squadra s1 = new Squadra();
        Squadra s2 = new Squadra();

        s1.addGiocatore(g1);
        s1.addGiocatore(g2);
        s1.addGiocatore(g3);
        s1.addGiocatore(g4);
        s1.addGiocatore(g5);
        s2.addGiocatore(g6);
        s2.addGiocatore(g7);
        s2.addGiocatore(g8);
        s2.addGiocatore(g9);
        s2.addGiocatore(g10);

        Random rand = new Random();
        int n = 0;

        for(int i = 0; i < 10; i++){
            n = rand.nextInt(10) + 1;
            switch (n) {
                case 1:
                    g1.addGoal();
                    break;
                case 2:
                    g2.addGoal();
                    break;
                case 3:
                    g3.addGoal();
                    break;
                case 4:
                    g4.addGoal();
                    break;
                case 5:
                    g5.addGoal();
                    break;
                case 6:
                    g6.addGoal();
                    break;
                case 7:
                    g7.addGoal();
                    break;
                case 8:
                    g8.addGoal();
                    break;
                case 9:
                    g9.addGoal();
                    break;
                case 10:
                    g10.addGoal();
                    break;
                default:
                    throw new AssertionError();
            }
        }

    }
}
