import java.util.ArrayList;

public class Squadra {
    private ArrayList<Giocatore> squadra;

    public Squadra(){
        this.squadra = new ArrayList<Giocatore>(5);
    }

    public void addGiocatore(Giocatore g){
        this.squadra.add(g);
    }

    public Giocatore maxGoal(){
        for(Giocatore g : squadra){
        
        }
    }
}
