
import java.time.LocalDate;

public class Giocatore extends Atleta{
    private int nMaglia;
    private String ruolo;
    private String pPreferito;
    private int nGoal;

    public Giocatore(int nMaglia, String pPreferito, String ruolo, double altezza, LocalDate bDay, String cognome, String nome, double peso) {
        super(altezza, bDay, cognome, nome, peso);
        this.nGoal = 0;
        this.nMaglia = nMaglia;
        this.pPreferito = pPreferito;
        this.ruolo = ruolo;
    }

    public int getnMaglia() {
        return nMaglia;
    }

    public void setnMaglia(int nMaglia) {
        this.nMaglia = nMaglia;
    }

    public String getRuolo() {
        return ruolo;
    }

    public void setRuolo(String ruolo) {
        this.ruolo = ruolo;
    }

    public String getpPreferito() {
        return pPreferito;
    }

    public void setpPreferito(String pPreferito) {
        this.pPreferito = pPreferito;
    }

    public int getnGoal() {
        return nGoal;
    }

    public void setnGoal(int nGoal) {
        this.nGoal = nGoal;
    }

    public void addGoal(){
        this.nGoal++;
    }
    
}
