public class Main {
    public static void main(String[] args){
        Rettangolo r1 = new Rettangolo(1.0, 1.0, 2.0, 2.0);
        System.out.println(r1.area());
        System.out.println(r1.perimetro());
        System.out.println(r1.diagonale());
    }
}
